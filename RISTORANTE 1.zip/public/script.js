
function showTab(tabName) {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.classList.remove('active');
  });
  document.getElementById(tabName).classList.add('active');
}

function handleSubmit(event) {
  event.preventDefault();
  document.getElementById('form-risposta').textContent = "Grazie per averci contattato!";
  event.target.reset();
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelector('#contact-form').addEventListener('submit', handleSubmit);
  showTab('menu');
});
